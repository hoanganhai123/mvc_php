<?php
require_once("./views/layout/header.php");
?>

Đây là file <?php echo $hi; ?>


<?php
require_once("./views/layout/footer.php");
?>