Đây là trang example
<?php
echo "biến : " . $hi;
print_r($test);
?>