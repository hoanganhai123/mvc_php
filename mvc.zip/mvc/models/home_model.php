<?php
class Home_model extends Base_model 
{
  // xử lý các hàm trả về render
  public function test(){
    return "test file trang chủ";
  }
  
}