<?php

class Db{
  // dữ liệu database
  const HOST = "localhost";
  const USERNAME = "";
  const PASSWORD = "@";
  const DB_NAME = "";
  public function connect(){
    $connect = mysqli_connect(self::HOST, self::USERNAME, self::PASSWORD, self::DB_NAME );
    mysqli_set_charset($connect,"utf8");
    if(mysqli_connect_errno() === 0){
      return $connect;
    }
    return false;
  }
}
